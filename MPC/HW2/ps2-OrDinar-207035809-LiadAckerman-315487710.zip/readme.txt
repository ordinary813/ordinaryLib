Files in the zip:
1. HW2.py - contains the implementation of One Time Truth Table for 2 parties, the file prints possible outcomes for Alice and Bob's inputs.
2. truth_table.csv - contains the truth table for equation 2.
3. test.txt - contains the output of HW2.py.
4. readme.txt - **this file**
5. HW2Doc.pdf for documentation of the script.
6. Latex Source files for HW2Doc.
