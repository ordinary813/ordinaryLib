SELECT PlayerName FROM players ORDER BY PlayerName DESC;
