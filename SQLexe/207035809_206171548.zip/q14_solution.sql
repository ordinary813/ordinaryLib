select team, count(team) from teams
group by team;