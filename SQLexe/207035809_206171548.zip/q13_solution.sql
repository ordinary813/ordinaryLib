select team, sum(wins) from teams
group by Team;