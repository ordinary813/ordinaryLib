select coach
from teams
where coach like '%a%';
