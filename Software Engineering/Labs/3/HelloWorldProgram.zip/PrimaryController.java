/**
 * Sample Skeleton for 'primary.fxml' Controller Class
 */

package org.example;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class PrimaryController
{
    private static int counter = 0;
    @FXML
    private TextField counterTF;

    @FXML // fx:id="helloBtn"
    private Button helloBtn; // Value injected by FXMLLoader

    @FXML // fx:id="helloTF"
    private TextField helloTF; // Value injected by FXMLLoader

    @FXML
    private ComboBox<String> listBox;

    @FXML
    void chooseFromList(ActionEvent event)
    {
        String chosen = listBox.getSelectionModel().getSelectedItem();
    }

    @FXML
    void sayHello(ActionEvent event)
    {
        if (counter % 2 == 0)
        {
            this.helloTF.setText("Hello World");
        } else if (counter % 2 == 1)
        {
            helloTF.setText("");
        }
        counter++;
        this.counterTF.setText(Integer.toString(counter));
    }

    @FXML
    void initialize()
    {
        assert counterTF != null : "fx:id=\"counterTF\" was not injected: check your FXML file 'primary.fxml'.";
        assert helloBtn != null : "fx:id=\"helloBtn\" was not injected: check your FXML file 'primary.fxml'.";
        assert helloTF != null : "fx:id=\"helloTF\" was not injected: check your FXML file 'primary.fxml'.";
        assert listBox != null : "fx:id=\"listBox\" was not injected: check your FXML file 'primary.fxml'.";

        listBox.getItems().add("first");
        listBox.getItems().add("second");

    }
}
