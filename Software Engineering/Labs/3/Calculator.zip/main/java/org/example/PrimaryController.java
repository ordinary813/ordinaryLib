package org.example;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class PrimaryController
{
    @FXML
    private ResourceBundle resources;
    @FXML
    private URL location;
    @FXML
    private TextField screen;
    @FXML
    private ComboBox<String> baseCB;
    @FXML
    private Button btn0;
    @FXML
    private Button btn1;
    @FXML
    private Button btn2;
    @FXML
    private Button btn3;
    @FXML
    private Button btn4;
    @FXML
    private Button btn5;
    @FXML
    private Button btn6;
    @FXML
    private Button btn7;
    @FXML
    private Button btn8;
    @FXML
    private Button btn9;
    @FXML
    private Button btnA;
    @FXML
    private Button btnB;
    @FXML
    private Button btnC;
    @FXML
    private Button btnD;
    @FXML
    private Button btnE;
    @FXML
    private Button btnF;
    @FXML
    private Button btnMinus;
    @FXML
    private Button btnPlus;
    @FXML
    private Button btnAsterisk;
    @FXML
    private Button btnSlash;
    @FXML
    private Button btnClear;
    @FXML
    private Button btnEqual;

    @FXML
    void appendDigit(ActionEvent event)
    {

    }

    @FXML
    void appendOperation(ActionEvent event)
    {

    }

    @FXML
    void clearScreen(ActionEvent event)
    {
        this.screen.setText("");
    }

    @FXML
    void computeExpression(ActionEvent event)
    {

    }

    @FXML
    void chooseFromList(ActionEvent event)
    {
        String chosen = baseCB.getSelectionModel().getSelectedItem();
    }

    @FXML
    void initialize()
    {
        baseCB.getItems().add("HEX");
        baseCB.getItems().add("DEC");
        baseCB.getItems().add("OCT");
        baseCB.getItems().add("BIN");
    }

}
